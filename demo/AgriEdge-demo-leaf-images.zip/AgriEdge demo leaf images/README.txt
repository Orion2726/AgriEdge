AgriEdge demo leaf images
=========================

For demonstrating "Check a sick plant" in the AgriEdge app.

1. Copy the folders to the phone (e.g. Pictures/AgriEdge demo).
2. In the app: Crops -> Check a sick plant.
3. Pick the crop named in the folder ("select Potato", "select Wheat", ...).
4. Tap Gallery and choose an image from that folder.

Each file name says what the app should show and how sure the model is,
checked with the same models and preprocessing the app uses. Every image was
checked to give the right answer above the app's 60% "Not sure" line.
Rice is the least certain model (about 66-82%).

To demo report sharing: tick "Share this detection (with location)" and tap
Save detection. Nearby phones get the report and photo over Bluetooth, and
it appears in the control panel's Field Reports (click it for the photo,
prediction and exact location).

Image sources and licences: SOURCES.txt
